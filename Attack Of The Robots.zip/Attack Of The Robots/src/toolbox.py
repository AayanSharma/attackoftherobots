import pygame
import math

#Kinda self explanatory
def getRotatedImage(image, rect, angle):
    newImage = pygame.transform.rotate(image, angle)
    newRect = newImage.get_rect(center=rect.center)
    return newImage, newRect

def angleBetweenPoints(x1,y1,x2,y2):
    x_difference = x2 - x1
    y_difference = y2 - y1
    angle = math.degrees(math.atan2(-y_difference, x_difference))
    return angle
def centeringCoords(thingy, screen):
    new_x = screen.get_width() / 2 - thingy.get_width() / 2
    new_y = screen.get_height() / 2 - thingy.get_height() / 2
    return new_x, new_y
