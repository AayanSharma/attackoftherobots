import pygame
import random
import projectile
import enemy
from explosion import Explosion


class Crate(pygame.sprite.Sprite):
    def __init__(self, screen, x, y, player):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.screen = screen
        self.x = x
        self.y = y
        self.image = pygame.image.load("../assets/Crate.png")
        self.explosion_images = []
        self.explosion_images.append(pygame.image.load("../assets/CrateRubble.png"))
        self.rect = self.image.get_rect()
        self.rect.center = self.x, self.y
        self.hit_counter = 0
        self.just_placed = True
        self.player = player
        self.EXPLODEYIMAGE = pygame.image.load("../assets/ExplosiveCrate.png")
        self.sfx_break = pygame.mixer.Sound("../assets/sfx/break.wav")

    def update(self, projectiles, explosions):
        self.screen.blit(self.image, self.rect)
        if not self.rect.colliderect(self.player.rect):
            self.just_placed = False
        for explosion in explosions:
            if explosion.damage:
                if self.rect.colliderect(explosion.rect):
                    self.hit_counter += 1

        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect):
                self.hit_counter += .5
                projectile.explode()
        if self.hit_counter == 1:
            self.image = pygame.image.load("../assets/CrackedCrate_Stage01.png")
        elif self.hit_counter == 2:
            self.image = pygame.image.load("../assets/CrackedCrate_Stage02.png")
        elif self.hit_counter == 3:
            self.image = pygame.image.load("../assets/CrackedCrate_Stage03.png")
        elif self.hit_counter >= 4:
            Explosion(self.screen, self.x, self.y, self.explosion_images, 20, 0, False)
            self.kill()
            self.sfx_break.play()


class ExplosiveCrate(Crate):
    def __init__(self, screen, x, y, player):
        Crate.__init__(self, screen, x, y, player)
        self.explosion_images = []
        self.explosion_images.append(pygame.image.load("../assets/LargeExplosion1.png"))
        self.explosion_images.append(pygame.image.load("../assets/LargeExplosion2.png"))
        self.explosion_images.append(pygame.image.load("../assets/LargeExplosion3.png"))
        self.sfx_explode = pygame.mixer.Sound("../assets/sfx/explosion-big.wav")


    def update(self, projectiles, explosions):
        for explosion in explosions:
            if explosion.damage:
                if self.rect.colliderect(explosion.rect):
                    self.hit_counter += 1
        self.screen.blit(self.EXPLODEYIMAGE, self.rect)
        if not self.rect.colliderect(self.player.rect):
            self.just_placed = False
        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect):
                self.hit_counter += 1
                projectile.explode()
        if self.hit_counter == 1:
            self.EXPLODEYIMAGE = pygame.image.load("../assets/CrackedExplosiveCrate_Stage01.png")
        elif self.hit_counter == 2:
            self.EXPLODEYIMAGE = pygame.image.load("../assets/CrackedExplosiveCrate_Stage02.png")
        elif self.hit_counter == 3:
            self.EXPLODEYIMAGE = pygame.image.load("../assets/CrackedExplosiveCrate_Stage03.png")
        elif self.hit_counter >= 4:
            self.sfx_explode.play()
            Explosion(self.screen, self.x, self.y, self.explosion_images, 5, 10, True)
            self.kill()

