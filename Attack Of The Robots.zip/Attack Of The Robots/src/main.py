import pygame
import random
import toolbox
from player import Player
from projectile import WaterBalloon
from enemy import Enemy
from crate import Crate
from crate import ExplosiveCrate
from explosion import Explosion
from powerup import PowerUp
from hud import HUD

# Start the game
pygame.init()
pygame.mixer.pre_init(buffer=1000)
game_width = 1000
game_height = 650
screen = pygame.display.set_mode((game_width, game_height))
clock = pygame.time.Clock()
running = True
background_image = pygame.image.load("../assets/BG_Urban.png")
# Sprites need groups....
player_group = pygame.sprite.Group()
projectile_group = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()
crate_group = pygame.sprite.Group()
explosion_group = pygame.sprite.Group()
powerup_group = pygame.sprite.Group()
# And they need to be in those groups.  
Player.containers = player_group
WaterBalloon.containers = projectile_group
Enemy.containers = enemy_group
Crate.containers = crate_group
Explosion.containers = explosion_group
PowerUp.containers = powerup_group

enemy_spawn_timer_max = 100
enemy_spawn_timer = 10
enemy_spawn_speedup_timer_max = 100
enemy_spawn_speedup_timer = enemy_spawn_speedup_timer_max


game_started = False

player = Player(screen, 158, 310, 100);

hud = HUD(screen, player)


def boxFort():
    # Box fort
    Crate(screen, 15, 213, player)
    Crate(screen, 45, 213, player)
    Crate(screen, 75, 213, player)
    Crate(screen, 105, 213, player)
    Crate(screen, 135, 213, player)
    Crate(screen, 165, 213, player)
    Crate(screen, 195, 213, player)
    Crate(screen, 225, 213, player)
    Crate(screen, 255, 213, player)
    Crate(screen, 285, 213, player)
    Crate(screen, 315, 213, player)
    Crate(screen, 345, 213, player)

    Crate(screen, 375, 213, player)
    Crate(screen, 375, 243, player)
    Crate(screen, 375, 373, player)
    Crate(screen, 375, 313, player)
    Crate(screen, 375, 343, player)
    Crate(screen, 375, 403, player)

    Crate(screen, 15, 403, player)
    Crate(screen, 45, 403, player)
    Crate(screen, 75, 403, player)
    Crate(screen, 105, 403, player)
    Crate(screen, 135, 403, player)
    Crate(screen, 165, 403, player)
    Crate(screen, 195, 403, player)
    Crate(screen, 225, 403, player)
    Crate(screen, 255, 403, player)
    Crate(screen, 285, 403, player)
    Crate(screen, 315, 403, player)
    Crate(screen, 345, 403, player)

    Crate(screen, 15, 213, player)
    Crate(screen, 15, 243, player)
    Crate(screen, 15, 373, player)
    Crate(screen, 15, 278, player)
    Crate(screen, 15, 313, player)
    Crate(screen, 15, 343, player)
    Crate(screen, 15, 403, player)


boxFort()

score_expectation = 500



def StartGame():
    global game_started
    global hud
    global player
    global enemy_spawn_timer_max
    game_started = True
    hud.state = "ingame"
    player.__init__(screen, 158, 310, player.health_max)
    enemy_spawn_timer_max = 100
    for i in range(0, 15):
        ExplosiveCrate(screen, random.randint(0, game_width), random.randint(0, game_height), player)
        Crate(screen, random.randint(0, game_width), random.randint(0, game_height), player)


# ***************** Loop Land Below *****************
# Everything under 'while running' will be repeated over and over again
while running:
    # Makes the game stop if the player clicks the X or presses esc
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False
    screen.blit(background_image, (0, 0))

    if not game_started:
        events = pygame.event.get()

        for event in events:
            if event.type == pygame.KEYDOWN:
                StartGame()
                break
    if game_started:
        keys = pygame.key.get_pressed()
        enemy_spawn_timer -= 1


        # WASD
        if keys[pygame.K_w]:
            player.move(0, -1, crate_group)
        if keys[pygame.K_s]:
            player.move(0, 1, crate_group)
        if keys[pygame.K_a]:
            player.move(-1, 0, crate_group)
        if keys[pygame.K_d]:
            player.move(1, 0, crate_group)
        if pygame.mouse.get_pressed()[0]:
            player.shoot()
        if keys[pygame.K_SPACE]:
            player.placeCrate()
        if pygame.mouse.get_pressed()[2]:
            player.placeExplosiveCrate()

        enemy_spawn_speedup_timer -= 1
        if enemy_spawn_speedup_timer <= 0:
            if enemy_spawn_timer_max > 20:
                 enemy_spawn_timer_max -= 1
            enemy_spawn_speedup_timer = enemy_spawn_speedup_timer_max

        if enemy_spawn_timer <= 0:
            new_enemy = Enemy(screen, 0, 0, player)
            side_to_spawn = random.randint(0, 3)
            if side_to_spawn == 0:
                new_enemy.x = random.randint(0, game_width)
                new_enemy.y = -new_enemy.image.get_height()
            elif side_to_spawn == 1:
                new_enemy.x = random.randint(0, game_width)
                new_enemy.y = game_height + new_enemy.image.get_height()
            elif side_to_spawn == 2:
                new_enemy.x = -new_enemy.image.get_width()
                new_enemy.y = random.randint(0, game_height)
            elif side_to_spawn == 3:
                new_enemy.x = game_width + new_enemy.image.get_width()
                new_enemy.y = random.randint(0, game_height)
            enemy_spawn_timer = enemy_spawn_timer_max

        for PowerUp in powerup_group:
            PowerUp.update(player)
        for projectile in projectile_group:
            projectile.update()
        for enemy in enemy_group:
            enemy.update(projectile_group, crate_group, explosion_group)
        for crate in crate_group:
            crate.update(projectile_group, explosion_group)
        for explosion in explosion_group:
            explosion.update()
        player.update(enemy_group, explosion_group)

        if not player.alive:
            if hud.state == "ingame":
                hud.state = "game_over"
            elif hud.state == "mainmenu":
                game_started = False
                player_group.empty()
                enemy_group.empty()
                projectile_group.empty()
                powerup_group.empty()
                explosion_group.empty()
                crate_group.empty()
                boxFort()

    hud.update()

    # Tell pygame to update the screen
    pygame.display.flip()
    clock.tick(9999999999999999999999999999999999999999999999999999999999999999999999999999)
    pygame.display.set_caption("Attack Of The Robots | FPS: " + str(clock.get_fps()))
